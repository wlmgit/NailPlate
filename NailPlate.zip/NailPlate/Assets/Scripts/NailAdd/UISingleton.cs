﻿using UnityEngine;
using System.Collections;

public class UISingleton : MonoBehaviour {

	#region
	private static UISingleton mUIInstance;

	private int NailCount;

	public GameObject panel_nail;

	public static UISingleton UIInstance
	{
		get
		{
			if(mUIInstance==null)
			{
				mUIInstance=new UISingleton();
			}
			return mUIInstance;
		}
	}
	    
	void Awake()
	{
		mUIInstance = this;	
	}
	#endregion

	public GameObject mNailPanel;
	public GameObject mElashPanel;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void Nail_click()
	{
		mNailPanel.SetActive (true);
		mElashPanel.SetActive (false);
	}
	void Elash_click()
	{
		mNailPanel.SetActive (false);
		mElashPanel.SetActive (true);
	}
	void setNail5()
	{
		NailCount = 5;
		panel_nail.SetActive (true);
	}
	void setNail6()
	{
		NailCount = 6;
		panel_nail.SetActive (true);
	}
	void setNail8()
	{
		NailCount = 8;
		panel_nail.SetActive (true);
	}
	void setNail12()
	{
		NailCount = 12;
		panel_nail.SetActive (true);
	}
	void setNail(int nailCount)
	{
		GameControl.GameControlInstance.NailStyle=nailCount;
		GameControl.GameControlInstance.InitNail();
		GameControl.GameControlInstance.set_Nail (nailCount);
		GameControl.GameControlInstance.setParent ();
		GameControl.mLines.Clear ();
	}


	void removeGameControl(int count)
	{
		int maxCount = GameControl.mLines.Count - 1;
		for (int i=0; i<count; i++) 
		{
			GameControl.mLines.RemoveAt(maxCount);
			maxCount--;
		}
	}
	void btn_qx()
	{
		panel_nail.SetActive (false);
	}
}
